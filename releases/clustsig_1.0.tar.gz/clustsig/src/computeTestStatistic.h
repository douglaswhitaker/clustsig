#ifndef COMPUTETESTSTATISTIC_H
#define COMPUTETESTSTATISTIC_H

#include <R.h>
#include <Rdefines.h>
#include <R_ext/Utils.h>
#include <math.h>
extern SEXP computeTestStatistic(SEXP data, SEXP averages, SEXP length);

#endif
